Libraries for the A-Star 32U4 controllers and Zumo 32U4 robot can be found in
their own repositories:

* [AStar32U4 library](https://github.com/pololu/a-star-32u4-arduino-library)
* [Zumo32U4 library](https://github.com/pololu/zumo-32u4-arduino-library)
