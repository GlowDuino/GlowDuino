# GlowDuino software package for all GlowDuino boards

Version: 2.0.1<br>
Release date: 2022-011-03<br>
Modified from the software package made for the a-star boards by Pololulu.

For more information about these boards, visit our [GitHub](https://github.com/GlowDuino/GlowDuino) page!


## Arduino IDE integration

To install the software package in Arduino IDE, please refer to the most up-to-date instruction on our [GitHub](https://github.com/GlowDuino/GlowDuino) page!

## ATmega328PB support in the Arduino IDE

GlowDuino boards use the ATmega328PB chips which contain additional features compared to the P variant. 
Here are some details about what Arduino features work when programming the
GlowDuino boards in the Arduino IDE:

- The `Serial` and `Serial1` objects both works, providing access to UART0 and
  UART1, respectively.
- There is no library support for accessing the ATmega328PB's second I2C module
  (TWI1), or its second SPI module (SPI1).  However, you can access the
  registers for those new modules and define ISRs for them.
- `pinMode()`, `digitalRead()`, and `digitalWrite()` should work on every I/O
  pin.
- `analogRead()` should work on every analog pin (A0 through A7).
- `analogWrite()` should work on every pin with PWM.

The ATmega328PB has two new pins, PE0 and PE1, that have no equivalent on the
ATmega328P.  These pins do not yet have official pin numbers in the Arduino
environment, so if you need to use their pin numbers in your code, we recommend
using the constants `SDA1` (for PE0) and `SCL1` (for PE1) which are defined in
our header files.  For example:

```c++
digitalWrite(SDA1, HIGH);
```

## Bootloader

The "bootloader" directory contains the source code and compiled files for the
bootloaders for the GlowDuino boards. All released boards use optiboot. The already compiled 
bootloaders also contain an idle animation to play when the bootloader is first uploaded.
